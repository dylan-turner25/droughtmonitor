# SPDX-FileCopyrightText: 2025-present Dylan Turner <dylan.turner3@outlook.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
