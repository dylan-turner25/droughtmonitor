fips_codes <- tidycensus::fips_codes
write.csv(fips_codes,"./src/droughtmonitor/data/fips_codes.csv")